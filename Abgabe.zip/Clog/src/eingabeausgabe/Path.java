package eingabeausgabe;

import java.io.File;

public class Path extends File {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7848885210765353558L;

	public Path(String path){
		super(path);
	}
}
