package menues;

import data.DatensatzManager;

public class Menue6 {
	public static void menue(){
		DatensatzManager.ausgeben();
	}
}
