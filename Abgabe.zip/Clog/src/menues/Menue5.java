package menues;

import eingabeausgabe.Ausgabe;

public class Menue5 {
	public static void menue(){
		Ausgabe.printline("Programm wird beendet!");
		System.exit(0);
	}

}