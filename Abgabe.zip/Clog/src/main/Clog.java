package main;

import data.DatensatzManager;
import eingabeausgabe.Eingabe;
import menues.Menue0;

public class Clog {

	public static void main(String[] args) {
		Menue0.run();
	}
}