Die Kompilierung und Ausführung des Programmes erfolgt wie folgt:
cd Clog
javac src/main/Clog.java -cp ./src/
cd src
java main/Clog